function calculateBMI(weight, height) {

    const heightMeters =
        height / 100;

    const bmi =
        weight /
        (heightMeters * heightMeters);

    return bmi.toFixed(1);
}

function calculateCalories(minutes) {

    return minutes * 8;
}

function generatePlan(goal) {

    if (
        goal ===
        "Weight Loss"
    ) {
        return "4 rides per week";
    }

    if (
        goal ===
        "Performance"
    ) {
        return "2 interval rides plus 2 endurance rides";
    }

    return "3 endurance rides per week";
}