/* ==========================================
   CYCLEFIT PLANNER
   MAIN SCRIPT
========================================== */

document.addEventListener("DOMContentLoaded", initializePage);

/* ==========================================
   INITIALIZATION
========================================== */

function initializePage() {
    renderDashboard();
    setupDarkMode();
    setupMobileMenu();
}

/* ==========================================
   DASHBOARD
========================================== */

function renderDashboard() {

    const dashboard =
        document.getElementById("dashboard");

    if (!dashboard) {
        return;
    }

    const plans =
        JSON.parse(
            localStorage.getItem("plans")
        ) || [];

    const totalPlans =
        plans.length;

    const averageBMI =
        calculateAverageBMI(plans);

    const totalCalories =
        calculateTotalCalories(plans);

    dashboard.innerHTML = `
        <section class="stats-grid">

            <article class="stat-card">
                <h3>Total Plans</h3>
                <p class="stat-value">
                    ${totalPlans}
                </p>
            </article>

            <article class="stat-card">
                <h3>Average BMI</h3>
                <p class="stat-value">
                    ${averageBMI}
                </p>
            </article>

            <article class="stat-card">
                <h3>Total Calories</h3>
                <p class="stat-value">
                    ${totalCalories}
                </p>
            </article>

        </section>
    `;
}

/* ==========================================
   AVERAGE BMI
   Uses reduce()
========================================== */

function calculateAverageBMI(plans) {

    if (plans.length === 0) {
        return 0;
    }

    const totalBMI =
        plans.reduce(
            (sum, plan) =>
                sum + Number(plan.bmi),
            0
        );

    return (
        totalBMI / plans.length
    ).toFixed(1);
}

/* ==========================================
   TOTAL CALORIES
   Uses reduce()
========================================== */

function calculateTotalCalories(plans) {

    return plans.reduce(
        (sum, plan) =>
            sum + Number(plan.calories || 0),
        0
    );
}

/* ==========================================
   MOST POPULAR GOAL
========================================== */

function findMostPopularGoal(plans) {

    if (plans.length === 0) {
        return "None";
    }

    const goals = {};

    plans.forEach(plan => {

        if (goals[plan.goal]) {
            goals[plan.goal]++;
        } else {
            goals[plan.goal] = 1;
        }

    });

    let mostPopular = "";
    let highestCount = 0;

    for (const goal in goals) {

        if (goals[goal] > highestCount) {

            highestCount =
                goals[goal];

            mostPopular =
                goal;
        }
    }

    return mostPopular;
}

/* ==========================================
   DARK MODE
========================================== */

function setupDarkMode() {

    const darkButton =
        document.getElementById(
            "darkModeBtn"
        );

    if (!darkButton) {
        return;
    }

    darkButton.addEventListener(
        "click",
        toggleDarkMode
    );
}

function toggleDarkMode() {

    document.body.classList.toggle(
        "dark-mode"
    );

    const enabled =
        document.body.classList.contains(
            "dark-mode"
        );

    localStorage.setItem(
        "darkMode",
        enabled
    );
}

/* ==========================================
   RESTORE DARK MODE
========================================== */

const darkModeStored =
    localStorage.getItem(
        "darkMode"
    );

if (darkModeStored === "true") {

    document.addEventListener(
        "DOMContentLoaded",
        () => {
            document.body.classList.add(
                "dark-mode"
            );
        }
    );

}

/* ==========================================
   MOBILE MENU
========================================== */

function setupMobileMenu() {

    const menuButton =
        document.getElementById(
            "menuBtn"
        );

    const navigation =
        document.getElementById(
            "navigation"
        );

    if (!menuButton || !navigation) {
        return;
    }

    menuButton.addEventListener(
        "click",
        () => {

            navigation.classList.toggle(
                "show-menu"
            );

        }
    );
}