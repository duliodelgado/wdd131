/* ==========================================
   PLANNER PAGE
========================================== */

document.addEventListener("DOMContentLoaded", () => {
    renderPlans();

    const form = document.getElementById("planForm");

    if (form) {
        form.addEventListener("submit", generateTrainingPlan);
    }
});

/* ==========================================
   GENERATE PLAN
========================================== */

function generateTrainingPlan(event) {

    event.preventDefault();

    const name =
        document.getElementById("name").value;

    const weight =
        Number(
            document.getElementById("weight").value
        );

    const height =
        Number(
            document.getElementById("height").value
        );

    const minutes =
        Number(
            document.getElementById("minutes").value
        );

    const goal =
        document.getElementById("goal").value;

    if (
        !name ||
        weight <= 0 ||
        height <= 0 ||
        minutes <= 0
    ) {
        alert("Please complete all fields.");

        return;
    }

    const bmi =
        calculateBMI(
            weight,
            height
        );

    const calories =
        calculateCalories(
            minutes
        );

    const recommendation =
        generatePlan(
            goal
        );

    const results =
        document.getElementById(
            "results"
        );

    results.innerHTML = `
        <article class="results-card">

            <h3>Your Training Plan</h3>

            <div class="metric">
                <strong>Name:</strong>
                ${name}
            </div>

            <div class="metric">
                <strong>BMI:</strong>
                ${bmi}
            </div>

            <div class="metric">
                <strong>Calories:</strong>
                ${calories}
            </div>

            <div class="metric">
                <strong>Goal:</strong>
                ${goal}
            </div>

            <div class="metric">
                <strong>Recommendation:</strong>
                ${recommendation}
            </div>

        </article>
    `;

    const plan = {
        id: Date.now(),
        name,
        weight,
        height,
        minutes,
        goal,
        bmi,
        calories
    };

    savePlan(plan);

    renderPlans();

    document.getElementById(
        "planForm"
    ).reset();
}

/* ==========================================
   RENDER SAVED PLANS
========================================== */

function renderPlans() {

    const container =
        document.getElementById(
            "savedPlans"
        );

    if (!container) {
        return;
    }

    const plans = getPlans();

    if (plans.length === 0) {

        container.innerHTML = `
            <p>
                No saved plans yet.
            </p>
        `;

        return;
    }

    container.innerHTML =
        plans.map(plan => `
            <article class="plan-card">

                <h3>${plan.name}</h3>

                <p>
                    Goal:
                    ${plan.goal}
                </p>

                <p>
                    BMI:
                    ${plan.bmi}
                </p>

                <p>
                    Calories:
                    ${plan.calories}
                </p>

            </article>
        `).join("");
}