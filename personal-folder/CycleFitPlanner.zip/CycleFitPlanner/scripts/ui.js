function renderPlans() {

    const plans = getPlans();

    const container =
        document.getElementById(
            'savedPlans'
        );

    container.innerHTML = '';

    plans.forEach(plan => {

        container.innerHTML += `
            <article class="card">
                <h3>${plan.name}</h3>
                <p>BMI: ${plan.bmi}</p>
                <p>${plan.goal}</p>
            </article>
        `;

    });

}